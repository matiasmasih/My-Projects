<?php
// Start session and include database connection
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
$current_page = basename($_SERVER["PHP_SELF"]);
require_once 'connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Get user information
$user_query = "SELECT * FROM jasenet WHERE id = ?";
$stmt = $conn->prepare($user_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    session_destroy();
    header("Location: login.php");
    exit();
}

// Create membership number if not exists
$membership_number = isset($user['jasennumero']) && !empty($user['jasennumero'])
    ? $user['jasennumero']
    : 'JASEN-' . str_pad($user['id'], 6, '0', STR_PAD_LEFT);

// Initialize variables with default values
$available_books_count = 0;
$active_loans_count = 0;
$loan_history_count = 0;
$fines_total = 0;
$available_devices_count = 0;
$active_device_loans_count = 0;
$reservations_count = 0;
$overdue_loans_count = 0;

// Get available books count (from Kirjakopiot)
try {
    $available_books_query = "SELECT COUNT(*) as count FROM Kirjakopiot WHERE tila = 'saatavilla'";
    $available_books_result = $conn->query($available_books_query);
    if ($available_books_result) {
        $available_books = $available_books_result->fetch_assoc();
        $available_books_count = $available_books['count'];
    }
} catch (Exception $e) {
    error_log("Books count error: " . $e->getMessage());
}

// Get user's active loans count
try {
    $active_loans_query = "SELECT COUNT(*) as count FROM lainat WHERE jasen_id = ? AND tila = 'aktiivinen'";
    $stmt = $conn->prepare($active_loans_query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $active_loans_result = $stmt->get_result();
    $active_loans = $active_loans_result->fetch_assoc();
    $active_loans_count = $active_loans['count'];
} catch (Exception $e) {
    error_log("Active loans error: " . $e->getMessage());
}

// Get user's overdue loans count
try {
    $overdue_query = "SELECT COUNT(*) as count FROM lainat WHERE jasen_id = ? AND tila = 'myohassa'";
    $stmt = $conn->prepare($overdue_query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $overdue_result = $stmt->get_result();
    $overdue_data = $overdue_result->fetch_assoc();
    $overdue_loans_count = $overdue_data['count'];
} catch (Exception $e) {
    error_log("Overdue loans error: " . $e->getMessage());
}

// Get user's loan history count
try {
    $loan_history_query = "SELECT COUNT(*) as count FROM lainat WHERE jasen_id = ?";
    $stmt = $conn->prepare($loan_history_query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $loan_history_result = $stmt->get_result();
    $loan_history = $loan_history_result->fetch_assoc();
    $loan_history_count = $loan_history['count'];
} catch (Exception $e) {
    error_log("Loan history error: " . $e->getMessage());
}

// Get unpaid fines amount
try {
    $fines_query = "SELECT SUM(sakko_maara - IFNULL(maksettu_maara, 0)) as total FROM sakot WHERE jasen_id = ? AND tila IN ('maksettava', 'osittain')";
    $stmt = $conn->prepare($fines_query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $fines_result = $stmt->get_result();
    $fines_data = $fines_result->fetch_assoc();
    if ($fines_data && $fines_data['total'] !== null) {
        $fines_total = $fines_data['total'];
    }
} catch (Exception $e) {
    error_log("Fines error: " . $e->getMessage());
}

// Get available devices count
try {
    $devices_query = "SELECT COUNT(*) as count FROM Laitteet WHERE tila = 'saatavilla'";
    $devices_result = $conn->query($devices_query);
    if ($devices_result) {
        $devices = $devices_result->fetch_assoc();
        $available_devices_count = $devices['count'];
    }
} catch (Exception $e) {
    error_log("Devices count error: " . $e->getMessage());
}

// Get user's active device loans count
try {
    $device_loans_query = "SELECT COUNT(*) as count FROM Laitelainat WHERE jasen_id = ? AND palautus_pvm IS NULL";
    $stmt = $conn->prepare($device_loans_query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $device_loans_result = $stmt->get_result();
    $device_loans = $device_loans_result->fetch_assoc();
    $active_device_loans_count = $device_loans['count'];
} catch (Exception $e) {
    error_log("Device loans error: " . $e->getMessage());
}

// Get user's active reservations count
try {
    $reservations_query = "SELECT COUNT(*) as count FROM varaukset WHERE jasen_id = ? AND tila = 'odottaa'";
    $stmt = $conn->prepare($reservations_query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $reservations_result = $stmt->get_result();
    $reservations = $reservations_result->fetch_assoc();
    $reservations_count = $reservations['count'];
} catch (Exception $e) {
    error_log("Reservations error: " . $e->getMessage());
}

// Get available books list
$books_result = null;
try {
    $books_query = "SELECT DISTINCT k.id, k.nimi, k.tekija,
                           (SELECT COUNT(*) FROM Kirjakopiot kp WHERE kp.kirja_id = k.id AND kp.tila = 'saatavilla') as saatavilla
                    FROM kirjat k
                    WHERE EXISTS (SELECT 1 FROM Kirjakopiot kp WHERE kp.kirja_id = k.id AND kp.tila = 'saatavilla')
                    ORDER BY RAND() LIMIT 4";
    $books_result = $conn->query($books_query);
} catch (Exception $e) {
    error_log("Books list error: " . $e->getMessage());
}

// Get available devices list
$available_devices_result = null;
try {
    $devices_list_query = "SELECT id, merkki, malli, tila, kunto
                          FROM Laitteet
                          WHERE tila = 'saatavilla'
                          ORDER BY RAND() LIMIT 4";
    $available_devices_result = $conn->query($devices_list_query);
} catch (Exception $e) {
    error_log("Devices list error: " . $e->getMessage());
}

// Get current active loans
$current_loans_result = null;
try {
    $current_loans_query = "SELECT l.*, k.nimi, k.tekija
                          FROM lainat l
                          JOIN kirjat k ON l.kirja_id = k.id
                          WHERE l.jasen_id = ? AND l.tila IN ('aktiivinen', 'myohassa')
                          ORDER BY l.erapaiva ASC";
    $stmt = $conn->prepare($current_loans_query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $current_loans_result = $stmt->get_result();
} catch (Exception $e) {
    error_log("Current loans error: " . $e->getMessage());
}

// Get user's reservations
$reservations_result = null;
try {
    $reservations_query = "SELECT v.*, k.nimi, k.tekija
                          FROM varaukset v
                          JOIN kirjat k ON v.kirja_id = k.id
                          WHERE v.jasen_id = ? AND v.tila = 'odottaa'
                          ORDER BY v.varaus_paiva DESC";
    $stmt = $conn->prepare($reservations_query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $reservations_result = $stmt->get_result();
} catch (Exception $e) {
    error_log("Reservations list error: " . $e->getMessage());
}

// Handle message sending
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['send_message'])) {
    $message = $_POST['message'] ?? '';
    $recipient_id = $_POST['recipient_id'] ?? null;

    if ($message && $recipient_id) {
        $message_query = "INSERT INTO viestit (lahettaja_id, vastaanottaja_id, viesti) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($message_query);
        $stmt->bind_param("iis", $user_id, $recipient_id, $message);

        if ($stmt->execute()) {
            $message_success = "Viesti lähetetty onnistuneesti!";
        } else {
            $message_error = "Viestin lähetys epäonnistui: " . $conn->error;
        }
    } else {
        $message_error = "Täytä viesti ja valitse vastaanottaja.";
    }
}

// Get profile image
$profile_image = null;
$stmt = $conn->prepare("SELECT profile_image FROM jasenet WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $profile_image = $row['profile_image'];
}
// Get user initials for avatar
$initials = strtoupper(substr($user['etunimi'], 0, 1) . substr($user['sukunimi'], 0, 1));

// Get staff members for messaging (both admin and manager)
$staff_members = [];
try {
    $staff_query = "SELECT id, etunimi, sukunimi, rooli FROM jasenet WHERE rooli IN ('admin', 'manager') AND id != ?";
    $stmt = $conn->prepare($staff_query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $staff_result = $stmt->get_result();
    while ($staff = $staff_result->fetch_assoc()) {
        $staff_members[] = $staff;
    }
} catch (Exception $e) {
    error_log("Staff query error: " . $e->getMessage());
}

// Get unread messages count
$unread_messages_count = 0;
try {
    $unread_query = "SELECT COUNT(*) as count FROM viestit WHERE vastaanottaja_id = ? AND luettu = 0";
    $stmt = $conn->prepare($unread_query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $unread_result = $stmt->get_result();
    $unread_data = $unread_result->fetch_assoc();
    $unread_messages_count = $unread_data['count'] ?? 0;
} catch (Exception $e) {
    error_log("Unread messages error: " . $e->getMessage());
}

// Get all messages
$all_messages = [];
try {
    $messages_query = "SELECT v.*,
                      l.etunimi as lahettaja_etunimi, l.sukunimi as lahettaja_sukunimi, l.rooli as lahettaja_rooli,
                      v2.etunimi as vastaanottaja_etunimi, v2.sukunimi as vastaanottaja_sukunimi, v2.rooli as vastaanottaja_rooli
                      FROM viestit v
                      LEFT JOIN jasenet l ON v.lahettaja_id = l.id
                      LEFT JOIN jasenet v2 ON v.vastaanottaja_id = v2.id
                      WHERE v.lahettaja_id = ? OR v.vastaanottaja_id = ?
                      ORDER BY v.luontiaika DESC";
    $stmt = $conn->prepare($messages_query);
    $stmt->bind_param("ii", $user_id, $user_id);
    $stmt->execute();
    $messages_result = $stmt->get_result();
    while ($message = $messages_result->fetch_assoc()) {
        $all_messages[] = $message;
    }

    // Mark messages as read
    $mark_read_query = "UPDATE viestit SET luettu = 1 WHERE vastaanottaja_id = ? AND luettu = 0";
    $stmt = $conn->prepare($mark_read_query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
} catch (Exception $e) {
    error_log("Messages query error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | <?php echo htmlspecialchars($user['etunimi']); ?> <?php echo htmlspecialchars($user['sukunimi']); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            min-height: 100vh;
            display: flex;
            position: relative;
            background-color: #0a0c10;
        }

        /* Background Image with Overlay */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('https://images.unsplash.com/photo-1507842217343-583bb7270b66?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            filter: brightness(0.25) blur(4px);
            z-index: -1;
        }

        /* Dark Mode Colors */
        :root {
            --bg-primary: rgba(18, 22, 28, 0.85);
            --bg-secondary: rgba(26, 32, 39, 0.9);
            --bg-card: rgba(30, 36, 45, 0.85);
            --bg-sidebar: rgba(13, 17, 23, 0.95);
            --text-primary: #ffffff;
            --text-secondary: #b0b8c5;
            --text-muted: #94a3b8;
            --border-color: rgba(255, 255, 255, 0.08);
            --gradient-1: linear-gradient(135deg, #667eea, #764ba2);
            --gradient-2: linear-gradient(135deg, #f093fb, #f5576c);
            --gradient-3: linear-gradient(135deg, #4facfe, #00f2fe);
            --gradient-4: linear-gradient(135deg, #43e97b, #38f9d7);
            --gradient-5: linear-gradient(135deg, #fa709a, #fee140);
            --gradient-6: linear-gradient(135deg, #a8edea, #fed6e3);
            --gradient-7: linear-gradient(135deg, #ff9a9e, #fad0c4);
            --shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
            --shadow-hover: 0 15px 40px rgba(0, 0, 0, 0.6);
            --glow: 0 0 20px rgba(102, 126, 234, 0.3);
        }

        /* Modern Sidebar */
        .sidebar {
            width: 280px;
            background: var(--bg-sidebar);
            backdrop-filter: blur(10px);
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            box-shadow: var(--shadow);
            overflow-y: auto;
            z-index: 1000;
            border-right: 1px solid var(--border-color);
        }

        .sidebar-header {
            padding: 30px 24px;
            border-bottom: 1px solid var(--border-color);
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .logo-icon {
            width: 45px;
            height: 45px;
            background: var(--gradient-1);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.4rem;
            box-shadow: var(--glow);
        }

        .logo-text h2 {
            font-size: 1.4rem;
            font-weight: 700;
            background: var(--gradient-1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 2px;
        }

        .logo-text p {
            font-size: 0.7rem;
            color: var(--text-muted);
            letter-spacing: 0.5px;
        }

        .user-profile-mini {
            padding: 24px;
            display: flex;
            align-items: center;
            gap: 15px;
            border-bottom: 1px solid var(--border-color);
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
        }

        .user-profile-mini:hover {
            background: rgba(255, 255, 255, 0.05);
            transform: translateX(5px);
        }

        .avatar-mini {
            width: 55px;
            height: 55px;
            border-radius: 14px;
            overflow: hidden;
            background: var(--gradient-1);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 1.3rem;
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
            border: 2px solid rgba(255, 255, 255, 0.1);
        }

        .avatar-mini img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .user-info-mini h4 {
            font-size: 1rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 5px;
        }

        .user-info-mini p {
            font-size: 0.75rem;
            color: var(--text-muted);
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .user-info-mini p i {
            font-size: 0.7rem;
            color: #10b981;
        }

        .sidebar-menu {
            padding: 20px 16px;
        }

        .menu-section {
            font-size: 0.65rem;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--text-muted);
            padding: 20px 16px 8px;
            letter-spacing: 0.5px;
        }

        .menu-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            color: var(--text-secondary);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s;
            margin: 4px 0;
            font-weight: 500;
            font-size: 0.9rem;
        }

        .menu-item i {
            width: 22px;
            font-size: 1.1rem;
            color: var(--text-muted);
            transition: all 0.3s;
        }

        .menu-item:hover {
            background: rgba(255, 255, 255, 0.05);
            color: white;
            transform: translateX(5px);
        }

        .menu-item:hover i {
            color: #667eea;
        }

        .menu-item.active {
            background: var(--gradient-1);
            color: white;
            box-shadow: 0 10px 20px -5px rgba(102, 126, 234, 0.3);
        }

        .menu-item.active i {
            color: white;
        }

        .logout-item {
            margin-top: 30px;
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        .logout-item i {
            color: #ef4444;
        }

        .logout-item:hover {
            background: rgba(239, 68, 68, 0.1);
            color: #ef4444;
        }

        .logout-item:hover i {
            color: #ef4444;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 30px 40px;
        }

        /* Top Bar */
        .top-bar {
            background: var(--bg-card);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 20px 30px;
            margin-bottom: 30px;
            box-shadow: var(--shadow);
            display: flex;
            justify-content: space-between;
            align-items: center;
            border: 1px solid var(--border-color);
        }

        .page-title h1 {
            font-size: 1.8rem;
            font-weight: 700;
            background: var(--gradient-1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 5px;
        }

        .page-title p {
            color: var(--text-muted);
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .page-title p i {
            font-size: 0.5rem;
            color: #10b981;
        }

        .top-actions {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .date-badge {
            background: rgba(255, 255, 255, 0.05);
            padding: 8px 16px;
            border-radius: 30px;
            font-weight: 500;
            color: var(--text-secondary);
            font-size: 0.85rem;
            display: flex;
            align-items: center;
            gap: 8px;
            border: 1px solid var(--border-color);
        }

        .date-badge i {
            color: #667eea;
        }

        .notification-icon {
            position: relative;
            width: 45px;
            height: 45px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            color: var(--text-secondary);
            cursor: pointer;
            transition: all 0.3s;
            border: 1px solid var(--border-color);
        }

        .notification-icon:hover {
            background: var(--gradient-1);
            color: white;
            transform: rotate(5deg);
        }

        .badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: #ef4444;
            color: white;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            font-size: 0.65rem;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            border: 2px solid var(--bg-card);
        }

        /* Floating Message Button */
        .floating-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 70px;
            height: 70px;
            background: var(--gradient-1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.8rem;
            cursor: pointer;
            box-shadow: var(--shadow-hover), 0 0 30px rgba(102, 126, 234, 0.5);
            transition: all 0.3s;
            border: 3px solid rgba(255, 255, 255, 0.2);
            z-index: 100;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% {
                box-shadow: 0 0 0 0 rgba(102, 126, 234, 0.7);
            }
            70% {
                box-shadow: 0 0 0 15px rgba(102, 126, 234, 0);
            }
            100% {
                box-shadow: 0 0 0 0 rgba(102, 126, 234, 0);
            }
        }

        .floating-btn:hover {
            transform: scale(1.1) rotate(10deg);
            background: var(--gradient-2);
        }

        .floating-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: #ef4444;
            color: white;
            width: 28px;
            height: 28px;
            border-radius: 50%;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            border: 3px solid var(--bg-card);
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(10px);
            z-index: 2000;
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background: var(--bg-card);
            backdrop-filter: blur(10px);
            border-radius: 30px;
            padding: 35px;
            width: 90%;
            max-width: 600px;
            box-shadow: var(--shadow-hover);
            animation: slideUp 0.4s ease;
            border: 1px solid var(--border-color);
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .modal-header h3 {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .modal-header h3 i {
            color: #667eea;
        }

        .close-btn {
            width: 45px;
            height: 45px;
            border-radius: 12px;
            border: none;
            background: rgba(255, 255, 255, 0.05);
            color: var(--text-muted);
            font-size: 1.3rem;
            cursor: pointer;
            transition: all 0.3s;
            border: 1px solid var(--border-color);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .close-btn:hover {
            background: #ef4444;
            color: white;
            transform: rotate(90deg);
        }

        /* Tab Styles */
        .tab-container {
            margin-bottom: 25px;
        }

        .tab-buttons {
            display: flex;
            gap: 10px;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 15px;
            margin-bottom: 20px;
        }

        .tab-btn {
            padding: 10px 20px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--border-color);
            font-size: 0.95rem;
            font-weight: 600;
            color: var(--text-muted);
            cursor: pointer;
            transition: all 0.3s;
            border-radius: 30px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .tab-btn i {
            font-size: 1rem;
        }

        .tab-btn:hover {
            background: rgba(102, 126, 234, 0.2);
            color: #667eea;
            border-color: #667eea;
        }

        .tab-btn.active {
            background: var(--gradient-1);
            color: white;
            border-color: transparent;
        }

        .tab-pane {
            display: none;
        }

        .tab-pane.active {
            display: block;
        }

        .message-count {
            background: #ef4444;
            color: white;
            padding: 2px 8px;
            border-radius: 30px;
            font-size: 0.7rem;
            margin-left: 5px;
        }

        /* Form Styles */
        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-size: 0.9rem;
            font-weight: 600;
            color: var(--text-primary);
        }

        .form-control {
            width: 100%;
            padding: 14px 18px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--border-color);
            border-radius: 14px;
            font-size: 0.95rem;
            color: var(--text-primary);
            transition: all 0.3s;
        }

        .form-control:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        }

        textarea.form-control {
            min-height: 120px;
            resize: vertical;
        }

        .staff-list {
            max-height: 250px;
            overflow-y: auto;
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid var(--border-color);
            border-radius: 14px;
            padding: 10px;
            margin-bottom: 10px;
        }

        .staff-item {
            padding: 12px 15px;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s;
            margin-bottom: 5px;
            border: 1px solid transparent;
        }

        .staff-item:hover {
            background: rgba(255, 255, 255, 0.05);
            border-color: rgba(102, 126, 234, 0.3);
        }

        .staff-item.selected {
            background: rgba(102, 126, 234, 0.2);
            border-color: #667eea;
        }

        .staff-item div, .staff-item span {
            color: var(--text-primary) !important;
        }

        .role-badge {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 30px;
            font-size: 0.7rem;
            font-weight: 600;
            margin-left: 8px;
        }

        .role-badge.admin {
            background: rgba(102, 126, 234, 0.2);
            color: #667eea !important;
            border: 1px solid rgba(102, 126, 234, 0.3);
        }

        .role-badge.manager {
            background: rgba(16, 185, 129, 0.2);
            color: #10b981 !important;
            border: 1px solid rgba(16, 185, 129, 0.3);
        }

        /* Messages List */
        .messages-list {
            max-height: 400px;
            overflow-y: auto;
        }

        .message-item {
            padding: 15px;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.03);
            margin-bottom: 10px;
            transition: all 0.3s;
            border: 1px solid var(--border-color);
        }

        .message-item:hover {
            transform: translateX(5px);
            background: rgba(255, 255, 255, 0.05);
        }

        .message-item.unread {
            background: rgba(245, 158, 11, 0.1);
            border-left: 4px solid #f59e0b;
        }

        .message-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            font-size: 0.85rem;
        }

        .message-sender {
            font-weight: 600;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .message-time {
            color: var(--text-muted);
        }

        .message-content {
            color: var(--text-secondary);
            line-height: 1.5;
            font-size: 0.9rem;
        }

        /* Welcome Banner */
        .welcome-banner {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.9), rgba(118, 75, 162, 0.9));
            backdrop-filter: blur(10px);
            border-radius: 30px;
            padding: 35px 40px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
            box-shadow: var(--shadow);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .welcome-text h2 {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 10px;
        }

        .welcome-text p {
            font-size: 1rem;
            opacity: 0.9;
            max-width: 500px;
        }

        .membership-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: rgba(255, 255, 255, 0.15);
            padding: 8px 20px;
            border-radius: 40px;
            font-size: 0.9rem;
            margin-top: 15px;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .welcome-stats {
            display: flex;
            gap: 40px;
        }

        .welcome-stat {
            text-align: center;
        }

        .welcome-stat .number {
            font-size: 2.2rem;
            font-weight: 700;
            line-height: 1;
            margin-bottom: 5px;
        }

        .welcome-stat .label {
            font-size: 0.8rem;
            opacity: 0.8;
        }

        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: var(--bg-card);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 25px;
            box-shadow: var(--shadow);
            border: 1px solid var(--border-color);
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-hover);
            border-color: rgba(102, 126, 234, 0.3);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.6rem;
            color: white;
        }

        .stat-icon.primary {
            background: var(--gradient-1);
        }

        .stat-icon.success {
            background: var(--gradient-4);
        }

        .stat-icon.warning {
            background: var(--gradient-5);
        }

        .stat-icon.info {
            background: var(--gradient-3);
        }

        .stat-icon.danger {
            background: linear-gradient(135deg, #ef4444, #f87171);
        }

        .stat-icon.purple {
            background: linear-gradient(135deg, #8b5cf6, #a78bfa);
        }

        .stat-details h3 {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--text-primary);
            line-height: 1.2;
            margin-bottom: 5px;
        }

        .stat-details p {
            font-size: 0.85rem;
            color: var(--text-muted);
            font-weight: 500;
        }

        /* Quick Actions */
        .quick-actions-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            margin-bottom: 30px;
        }

        .quick-action-card {
            background: var(--bg-card);
            backdrop-filter: blur(10px);
            padding: 20px;
            border-radius: 16px;
            text-align: center;
            border: 1px solid var(--border-color);
            transition: all 0.3s;
            cursor: pointer;
            text-decoration: none;
            display: block;
        }

        .quick-action-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-hover);
            border-color: #667eea;
        }

        .quick-action-card i {
            font-size: 2rem;
            margin-bottom: 10px;
            background: var(--gradient-1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .quick-action-card h4 {
            font-size: 1rem;
            color: var(--text-primary);
            font-weight: 600;
        }

        /* Section Styles */
        .section {
            background: var(--bg-card);
            backdrop-filter: blur(10px);
            border-radius: 24px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: var(--shadow);
            border: 1px solid var(--border-color);
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--border-color);
        }

        .section-header h2 {
            font-size: 1.3rem;
            font-weight: 600;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .section-header h2 i {
            color: #667eea;
            font-size: 1.2rem;
        }

        .view-all {
            color: #667eea;
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 5px;
            transition: all 0.3s;
            padding: 8px 15px;
            background: rgba(102, 126, 234, 0.1);
            border-radius: 30px;
            border: 1px solid rgba(102, 126, 234, 0.2);
        }

        .view-all:hover {
            gap: 10px;
            background: var(--gradient-1);
            color: white;
        }

        /* Card Grid */
        .card-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
        }

        .item-card {
            background: rgba(0, 0, 0, 0.3);
            border-radius: 20px;
            overflow: hidden;
            border: 1px solid var(--border-color);
            transition: all 0.3s;
        }

        .item-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-hover);
            border-color: #667eea;
        }

        .card-image {
            height: 150px;
            background: var(--gradient-1);
            position: relative;
        }

        .card-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .card-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background: rgba(0, 0, 0, 0.8);
            padding: 5px 10px;
            border-radius: 30px;
            font-size: 0.7rem;
            font-weight: 600;
            color: white;
            backdrop-filter: blur(5px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .card-content {
            padding: 18px;
        }

        .card-title {
            font-size: 1rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 5px;
        }

        .card-subtitle {
            font-size: 0.85rem;
            color: var(--text-muted);
            margin-bottom: 12px;
        }

        .card-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .card-status {
            font-size: 0.75rem;
            padding: 4px 10px;
            border-radius: 30px;
            background: rgba(16, 185, 129, 0.15);
            color: #10b981;
            font-weight: 500;
            border: 1px solid rgba(16, 185, 129, 0.3);
        }

        .card-action {
            width: 35px;
            height: 35px;
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.05);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #667eea;
            text-decoration: none;
            transition: all 0.3s;
            border: 1px solid var(--border-color);
        }

        .card-action:hover {
            background: #667eea;
            color: white;
            transform: rotate(90deg);
        }

        /* Table Styles */
        .table-responsive {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            text-align: left;
            padding: 15px;
            font-size: 0.8rem;
            font-weight: 600;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            background: rgba(255, 255, 255, 0.02);
            border-bottom: 1px solid var(--border-color);
        }

        td {
            padding: 15px;
            border-bottom: 1px solid var(--border-color);
            color: var(--text-secondary);
            font-size: 0.95rem;
        }

        tr:last-child td {
            border-bottom: none;
        }

        tr:hover td {
            background: rgba(255, 255, 255, 0.02);
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 5px 12px;
            border-radius: 30px;
            font-size: 0.8rem;
            font-weight: 500;
        }

        .status-active {
            background: rgba(16, 185, 129, 0.15);
            color: #10b981;
            border: 1px solid rgba(16, 185, 129, 0.3);
        }

        .status-warning {
            background: rgba(245, 158, 11, 0.15);
            color: #f59e0b;
            border: 1px solid rgba(245, 158, 11, 0.3);
        }

        .status-danger {
            background: rgba(239, 68, 68, 0.15);
            color: #ef4444;
            border: 1px solid rgba(239, 68, 68, 0.3);
        }

        .status-info {
            background: rgba(59, 130, 246, 0.15);
            color: #3b82f6;
            border: 1px solid rgba(59, 130, 246, 0.3);
        }

        .btn-small {
            padding: 6px 14px;
            border-radius: 10px;
            font-size: 0.8rem;
            font-weight: 500;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
        }

        .btn-primary {
            background: var(--gradient-1);
            color: white;
        }

        .btn-primary:hover {
            opacity: 0.9;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        .btn-outline {
            background: transparent;
            border: 1px solid var(--border-color);
            color: var(--text-secondary);
        }

        .btn-outline:hover {
            background: rgba(102, 126, 234, 0.1);
            border-color: #667eea;
            color: #667eea;
        }

        /* Alert Styles */
        .alert {
            padding: 15px 20px;
            border-radius: 14px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideIn 0.3s ease;
            backdrop-filter: blur(10px);
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert-success {
            background: rgba(16, 185, 129, 0.15);
            color: #10b981;
            border: 1px solid rgba(16, 185, 129, 0.3);
        }

        .alert-error {
            background: rgba(239, 68, 68, 0.15);
            color: #ef4444;
            border: 1px solid rgba(239, 68, 68, 0.3);
        }

        /* Scrollbar Styling */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }

        ::-webkit-scrollbar-track {
            background: rgba(0, 0, 0, 0.2);
        }

        ::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 10px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, #764ba2, #667eea);
        }

        /* Responsive */
        @media (max-width: 1200px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            .card-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            .quick-actions-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 1024px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .main-content {
                margin-left: 0;
                padding: 20px;
            }
        }

        @media (max-width: 768px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }
            .card-grid {
                grid-template-columns: 1fr;
            }
            .quick-actions-grid {
                grid-template-columns: 1fr;
            }
            .welcome-banner {
                flex-direction: column;
                text-align: center;
                gap: 20px;
            }
            .welcome-stats {
                gap: 20px;
            }
            .top-bar {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
            .modal-content {
                padding: 25px;
            }
        }
    </style>
</head>
<body>
    <!-- Modern Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-icon">
                    <i class="fas fa-book-open"></i>
                </div>
                <div class="logo-text">
                    <h2>Kirjasto</h2>
                    <p>Lukemisen iloa</p>
                </div>
            </div>
        </div>

        <!-- Profile Mini -->
        <a href="user_profile.php" class="user-profile-mini">
            <div class="avatar-mini">
                <?php if ($profile_image && file_exists("uploads/profiles/" . $profile_image)): ?>
                    <img src="uploads/profiles/<?php echo htmlspecialchars($profile_image); ?>" alt="Profiilikuva">
                <?php else: ?>
                    <?php echo $initials; ?>
                <?php endif; ?>
            </div>
            <div class="user-info-mini">
                <h4><?php echo htmlspecialchars($user['etunimi'] . ' ' . $user['sukunimi']); ?></h4>
                <p>
                    <i class="fas fa-id-card"></i> 
                    <?php echo htmlspecialchars($membership_number); ?>
                </p>
            </div>
        </a>

        <div class="sidebar-menu">
            <div class="menu-section">📊 Päävalikko</div>
            <a href="user_dashboard.php" class="menu-item <?php echo $current_page == 'user_dashboard.php' ? 'active' : ''; ?>">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>

            <div class="menu-section">📚 Kirjat</div>
            <a href="user_selaa_kirjoja.php" class="menu-item">
                <i class="fas fa-book"></i>
                <span>Selaa kirjoja</span>
            </a>
            <a href="user_lainaa_kirja.php" class="menu-item">
                <i class="fas fa-hand-holding-heart"></i>
                <span>Lainaa kirja</span>
            </a>
            <a href="user_lainahistoria.php" class="menu-item">
                <i class="fas fa-history"></i>
                <span>Lainahistoria</span>
            </a>
            <a href="user_oma_varaukset.php" class="menu-item">
                <i class="fas fa-clock"></i>
                <span>Omat varaukset</span>
            </a>
            <a href="user_suosikit.php" class="menu-item">
                <i class="fas fa-heart"></i>
                <span>Suosikit</span>
            </a>

            <div class="menu-section">💻 Laitteet</div>
            <a href="user_selaa_laitteita.php" class="menu-item">
                <i class="fas fa-laptop"></i>
                <span>Selaa laitteita</span>
            </a>
            <a href="user_laitelainat.php" class="menu-item">
                <i class="fas fa-microchip"></i>
                <span>Laitelainat</span>
            </a>

            <div class="menu-section">💰 Talous</div>
            <a href="user_sakot.php" class="menu-item">
                <i class="fas fa-euro-sign"></i>
                <span>Sakot</span>
            </a>
            <a href="user_kuitit.php" class="menu-item">
                <i class="fas fa-receipt"></i>
                <span>Kuitit</span>
            </a>

            <div class="menu-section">👤 Oma tili</div>
            <a href="user_profile.php" class="menu-item">
                <i class="fas fa-user-circle"></i>
                <span>Profiili</span>
            </a>
            <a href="user_yhteystiedot.php" class="menu-item">
                <i class="fas fa-address-card"></i>
                <span>Yhteystiedot</span>
            </a>
            <a href="salasana.php" class="menu-item">
                <i class="fas fa-key"></i>
                <span>Vaihda salasana</span>
            </a>
            <a href="user_kayttoehdot.php" class="menu-item">
                <i class="fas fa-file-contract"></i>
                <span>Käyttöehdot</span>
            </a>
            <a href="user_ilmoitukset.php" class="menu-item">
                <i class="fas fa-bell"></i>
                <span>Ilmoitukset</span>
            </a>

            <a href="logout.php" class="menu-item logout-item">
                <i class="fas fa-sign-out-alt"></i>
                <span>Kirjaudu ulos</span>
            </a>
        </div>
                <i class="fas fa-sign-out-alt"></i>
                <span>Kirjaudu Ulos</span>
            </a>
        </div>
    </div>

    <!-- Floating Message Button -->
    <div class="floating-btn" onclick="openMessageModal()">
        <i class="fas fa-comment-alt"></i>
        <?php if ($unread_messages_count > 0): ?>
            <span class="floating-badge"><?php echo $unread_messages_count; ?></span>
        <?php endif; ?>
    </div>

    <!-- Message Modal -->
    <div class="modal" id="messageModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-comments"></i> Viestit</h3>
                <button class="close-btn" onclick="closeMessageModal()">
                    <i class="fas fa-times"></i>
                </button>
            </div>

            <?php if (isset($message_success)): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $message_success; ?>
                </div>
            <?php endif; ?>

            <?php if (isset($message_error)): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-triangle"></i> <?php echo $message_error; ?>
                </div>
            <?php endif; ?>

            <div class="tab-container">
                <div class="tab-buttons">
                    <button class="tab-btn active" onclick="openTab(event, 'sendTab')">
                        <i class="fas fa-paper-plane"></i> Lähetä
                    </button>
                    <button class="tab-btn" onclick="openTab(event, 'inboxTab')">
                        <i class="fas fa-inbox"></i> Saapuneet
                        <?php if ($unread_messages_count > 0): ?>
                            <span class="message-count"><?php echo $unread_messages_count; ?></span>
                        <?php endif; ?>
                    </button>
                </div>

                <div id="sendTab" class="tab-pane active">
                    <form method="POST" action="">
                        <div class="form-group">
                            <label><i class="fas fa-user-tie"></i> Vastaanottaja</label>
                            <div class="staff-list">
                                <?php if (!empty($staff_members)): ?>
                                    <?php foreach ($staff_members as $staff): ?>
                                        <div class="staff-item" onclick="selectStaff(this, <?php echo $staff['id']; ?>)" style="color: white;">
                                            <div style="display: flex; align-items: center; gap: 10px; color: white;">
                                                <i class="fas fa-user-circle" style="color: #667eea; font-size: 1.2rem;"></i>
                                                <div style="font-weight: 600; color: white;">
                                                    <?php echo htmlspecialchars($staff['etunimi'] . ' ' . $staff['sukunimi']); ?>
                                                </div>
                                                <span class="role-badge <?php echo $staff['rooli']; ?>">
                                                    <?php echo $staff['rooli'] == 'admin' ? '👑 Admin' : '⭐ Manager'; ?>
                                                </span>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <div style="text-align: center; padding: 30px; color: var(--text-muted);">
                                        <i class="fas fa-users" style="font-size: 2rem; margin-bottom: 10px;"></i>
                                        <p>Ei henkilökuntaa saatavilla</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <input type="hidden" id="selectedStaffId" name="recipient_id" value="">
                        </div>

                        <div class="form-group">
                            <label><i class="fas fa-edit"></i> Viesti</label>
                            <textarea class="form-control" id="message" name="message" 
                                      placeholder="Kirjoita viestisi..." required></textarea>
                        </div>

                        <button type="submit" name="send_message" class="btn-primary" style="width: 100%; padding: 15px; border: none; border-radius: 14px; font-weight: 600; font-size: 1rem;">
                            <i class="fas fa-paper-plane"></i> Lähetä Viesti
                        </button>
                    </form>
                </div>

                <div id="inboxTab" class="tab-pane">
                    <div class="messages-list">
                        <?php if (!empty($all_messages)): ?>
                            <?php foreach ($all_messages as $msg): 
                                $is_sent = $msg['lahettaja_id'] == $user_id;
                                $is_unread = !$msg['luettu'] && !$is_sent;
                            ?>
                                <div class="message-item <?php echo $is_unread ? 'unread' : ''; ?>">
                                    <div class="message-header">
                                        <span class="message-sender">
                                            <?php if ($is_sent): ?>
                                                <i class="fas fa-check-circle" style="color: #10b981;"></i>
                                                <span>Sinä</span>
                                            <?php else: ?>
                                                <i class="fas fa-user-circle" style="color: #667eea;"></i>
                                                <span><?php echo htmlspecialchars($msg['lahettaja_etunimi'] . ' ' . $msg['lahettaja_sukunimi']); ?></span>
                                                <span class="role-badge <?php echo $msg['lahettaja_rooli']; ?>">
                                                    <?php echo $msg['lahettaja_rooli'] == 'admin' ? 'Admin' : 'Manager'; ?>
                                                </span>
                                            <?php endif; ?>
                                        </span>
                                        <span class="message-time">
                                            <i class="far fa-clock"></i> <?php echo date('d.m.Y H:i', strtotime($msg['luontiaika'])); ?>
                                        </span>
                                    </div>
                                    <div class="message-content">
                                        <?php echo nl2br(htmlspecialchars($msg['viesti'])); ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div style="text-align: center; padding: 50px; color: var(--text-muted);">
                                <i class="fas fa-inbox" style="font-size: 3rem; margin-bottom: 15px;"></i>
                                <p>Ei viestejä</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="page-title">
                <h1>Dashboard</h1>
                <p><i class="fas fa-circle"></i> Tervetuloa takaisin, <?php echo htmlspecialchars($user['etunimi']); ?></p>
            </div>
            <div class="top-actions">
                <div class="date-badge">
                    <i class="far fa-calendar-alt"></i>
                    <?php echo date('j. F Y'); ?>
                </div>
                <div class="notification-icon" onclick="openMessageModal()">
                    <i class="far fa-bell"></i>
                    <?php if ($unread_messages_count > 0): ?>
                        <span class="badge"><?php echo $unread_messages_count; ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Welcome Banner -->
        <div class="welcome-banner">
            <div class="welcome-text">
                <h2>Hei, <?php echo htmlspecialchars($user['etunimi']); ?>! 👋</h2>
                <p>Tutustu kirjaston uutuuskirjoihin ja lainaa laitteita helposti</p>
                <div class="membership-badge">
                    <i class="fas fa-id-card"></i>
                    <span>Jäsennumero: <?php echo htmlspecialchars($membership_number); ?></span>
                </div>
            </div>
            <div class="welcome-stats">
                <div class="welcome-stat">
                    <div class="number"><?php echo $available_books_count; ?></div>
                    <div class="label">Kopiota saatavilla</div>
                </div>
                <div class="welcome-stat">
                    <div class="number"><?php echo $available_devices_count; ?></div>
                    <div class="label">Laitetta saatavilla</div>
                </div>
                <div class="welcome-stat">
                    <div class="number"><?php echo $active_loans_count; ?></div>
                    <div class="label">Aktiiviset lainat</div>
                </div>
            </div>
        </div>

        <!-- Stats Grid -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon primary">
                    <i class="fas fa-copy"></i>
                </div>
                <div class="stat-details">
                    <h3><?php echo $available_books_count; ?></h3>
                    <p>Kirjakopiota saatavilla</p>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon success">
                    <i class="fas fa-book-reader"></i>
                </div>
                <div class="stat-details">
                    <h3><?php echo $active_loans_count; ?></h3>
                    <p>Aktiiviset lainat</p>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon warning">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <div class="stat-details">
                    <h3><?php echo $overdue_loans_count; ?></h3>
                    <p>Myöhässä olevat lainat</p>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon danger">
                    <i class="fas fa-euro-sign"></i>
                </div>
                <div class="stat-details">
                    <h3><?php echo number_format($fines_total, 2); ?> €</h3>
                    <p>Avonaiset sakot</p>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon info">
                    <i class="fas fa-laptop"></i>
                </div>
                <div class="stat-details">
                    <h3><?php echo $available_devices_count; ?></h3>
                    <p>Laitetta saatavilla</p>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon purple">
                    <i class="fas fa-clock"></i>
                </div>
                <div class="stat-details">
                    <h3><?php echo $reservations_count; ?></h3>
                    <p>Aktiiviset varaukset</p>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="quick-actions-grid">
            <a href="user_selaa_kirjoja.php" class="quick-action-card">
                <i class="fas fa-search"></i>
                <h4>Selaa Kirjoja</h4>
            </a>
            <a href="user_selaa_laitteita.php" class="quick-action-card">
                <i class="fas fa-laptop"></i>
                <h4>Selaa Laitteita</h4>
            </a>
            <a href="user_lainahistoria.php" class="quick-action-card">
                <i class="fas fa-history"></i>
                <h4>Lainahistoria</h4>
            </a>
            <a href="user_profile.php" class="quick-action-card">
                <i class="fas fa-user-cog"></i>
                <h4>Oma Profiili</h4>
            </a>
        </div>

        <!-- Current Active Loans -->
        <?php if ($current_loans_result && $current_loans_result->num_rows > 0): ?>
        <div class="section">
            <div class="section-header">
                <h2><i class="fas fa-book-reader"></i> Aktiiviset Lainat</h2>
                <a href="user_lainahistoria.php" class="view-all">
                    Näytä kaikki <i class="fas fa-arrow-right"></i>
                </a>
            </div>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Kirja</th>
                            <th>Tekijä</th>
                            <th>Lainauspäivä</th>
                            <th>Eräpäivä</th>
                            <th>Tila</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($loan = $current_loans_result->fetch_assoc()): 
                            $today = new DateTime();
                            $due_date = new DateTime($loan['erapaiva']);
                            $days_left = $today->diff($due_date)->days;
                            $is_overdue = $due_date < $today;
                        ?>
                        <tr>
                            <td><?php echo htmlspecialchars($loan['nimi']); ?></td>
                            <td><?php echo htmlspecialchars($loan['tekija']); ?></td>
                            <td><?php echo date('d.m.Y', strtotime($loan['lainauspaiva'])); ?></td>
                            <td><?php echo date('d.m.Y', strtotime($loan['erapaiva'])); ?></td>
                            <td>
                                <?php if ($loan['tila'] == 'myohassa' || $is_overdue): ?>
                                    <span class="status-badge status-danger">
                                        <i class="fas fa-exclamation-triangle"></i> Myöhässä
                                    </span>
                                <?php elseif ($days_left <= 3): ?>
                                    <span class="status-badge status-warning">
                                        <i class="fas fa-clock"></i> Palautus pian
                                    </span>
                                <?php else: ?>
                                    <span class="status-badge status-active">
                                        <i class="fas fa-check-circle"></i> Lainassa
                                    </span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>

        <!-- Available Books Section -->
        <div class="section">
            <div class="section-header">
                <h2><i class="fas fa-book-open"></i> Suositellut Kirjat</h2>
                <a href="user_selaa_kirjoja.php" class="view-all">
                    Näytä kaikki <i class="fas fa-arrow-right"></i>
                </a>
            </div>
            <div class="card-grid">
                <?php if ($books_result && $books_result->num_rows > 0): ?>
                    <?php while ($book = $books_result->fetch_assoc()): ?>
                        <div class="item-card">
                            <div class="card-image">
                                <div style="width: 100%; height: 100%; background: linear-gradient(135deg, #667eea, #764ba2); display: flex; align-items: center; justify-content: center; color: white;">
                                    <i class="fas fa-book" style="font-size: 2.5rem;"></i>
                                </div>
                                <span class="card-badge"><?php echo $book['saatavilla']; ?> kpl</span>
                            </div>
                            <div class="card-content">
                                <div class="card-title"><?php echo htmlspecialchars($book['nimi']); ?></div>
                                <div class="card-subtitle"><?php echo htmlspecialchars($book['tekija']); ?></div>
                                <div class="card-meta">
                                    <span class="card-status">Saatavilla</span>
                                    <a href="user_varaa_kirja.php?id=<?php echo $book['id']; ?>" class="card-action">
                                        <i class="fas fa-bookmark"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div style="grid-column: 1/-1; text-align: center; padding: 50px; color: var(--text-muted);">
                        <i class="fas fa-book" style="font-size: 3rem; margin-bottom: 15px;"></i>
                        <p>Ei kirjoja saatavilla tällä hetkellä</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

<!-- Available Devices Section -->
<div class="section">
    <div class="section-header">
        <h2><i class="fas fa-laptop"></i> Saatavilla Olevat Laitteet</h2>
        <a href="user_selaa_laitteita.php" class="view-all">
            Näytä kaikki <i class="fas fa-arrow-right"></i>
        </a>
    </div>
    <div class="card-grid">
        <?php if ($available_devices_result && $available_devices_result->num_rows > 0): ?>
            <?php while ($device = $available_devices_result->fetch_assoc()): ?>
                <div class="item-card">
                    <div class="card-image">
                        <div style="width: 100%; height: 100%; background: linear-gradient(135deg, #3b82f6, #60a5fa); display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-laptop" style="font-size: 2.5rem;"></i>
                        </div>
                        <span class="card-badge"><?php echo ucfirst($device['kunto'] ?? 'hyvä'); ?></span>
                    </div>
                    <div class="card-content">
                        <div class="card-title"><?php echo htmlspecialchars($device['merkki'] ?? 'Tuntematon'); ?></div>
                        <div class="card-subtitle"><?php echo htmlspecialchars($device['malli'] ?? ''); ?></div>
                        <div class="card-meta">
                            <span class="card-status">Saatavilla</span>
                            <a href="user_varaa_laite.php?id=<?php echo $device['id']; ?>" class="card-action">
                                <i class="fas fa-calendar-plus"></i>
                            </a>
                        </div>
                    </div>
                </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div style="grid-column: 1/-1; text-align: center; padding: 50px; color: var(--text-muted);">
                        <i class="fas fa-laptop" style="font-size: 3rem; margin-bottom: 15px;"></i>
                        <p>Ei laitteita saatavilla tällä hetkellä</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Active Reservations -->
        <?php if ($reservations_result && $reservations_result->num_rows > 0): ?>
        <div class="section">
            <div class="section-header">
                <h2><i class="fas fa-bookmark"></i> Omat Varaukset</h2>
                <a href="user_oma_varaukset.php" class="view-all">
                    Näytä kaikki <i class="fas fa-arrow-right"></i>
                </a>
            </div>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Kirja</th>
                            <th>Tekijä</th>
                            <th>Varauspäivä</th>
                            <th>Status</th>
                            <th>Toiminnot</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($reservation = $reservations_result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($reservation['nimi']); ?></td>
                            <td><?php echo htmlspecialchars($reservation['tekija']); ?></td>
                            <td><?php echo date('d.m.Y', strtotime($reservation['varaus_paiva'])); ?></td>
                            <td>
                                <span class="status-badge status-info">
                                    <i class="fas fa-clock"></i> Odottaa
                                </span>
                            </td>
                            <td>
                                <a href="peru_varaus.php?id=<?php echo $reservation['id']; ?>" class="btn-small btn-outline" onclick="return confirm('Haluatko varmasti peruuttaa varauksen?')">
                                    <i class="fas fa-times"></i> Peruuta
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <script>
        // Message Modal Functions
        function openMessageModal() {
            document.getElementById('messageModal').style.display = 'flex';
        }

        function closeMessageModal() {
            document.getElementById('messageModal').style.display = 'none';
        }

        // Tab Functions
        function openTab(event, tabName) {
            var i, tabPanes, tabBtns;
            
            tabPanes = document.getElementsByClassName('tab-pane');
            for (i = 0; i < tabPanes.length; i++) {
                tabPanes[i].classList.remove('active');
            }
            
            tabBtns = document.getElementsByClassName('tab-btn');
            for (i = 0; i < tabBtns.length; i++) {
                tabBtns[i].classList.remove('active');
            }
            
            document.getElementById(tabName).classList.add('active');
            event.currentTarget.classList.add('active');
        }

        // Staff Selection
        function selectStaff(element, staffId) {
            var staffItems = document.getElementsByClassName('staff-item');
            for (var i = 0; i < staffItems.length; i++) {
                staffItems[i].classList.remove('selected');
            }
            
            element.classList.add('selected');
            document.getElementById('selectedStaffId').value = staffId;
        }

        // Close modals when clicking outside
        window.onclick = function(event) {
            var messageModal = document.getElementById('messageModal');
            if (event.target == messageModal) {
                messageModal.style.display = 'none';
            }
        }

        // Keyboard shortcuts
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeMessageModal();
            }
            // Press M to open messages
            if (e.key === 'm' || e.key === 'M') {
                openMessageModal();
            }
        });

        // Auto-hide alerts after 5 seconds
        setTimeout(function() {
            var alerts = document.getElementsByClassName('alert');
            for (var i = 0; i < alerts.length; i++) {
                if (alerts[i]) {
                    alerts[i].style.transition = 'opacity 0.5s';
                    alerts[i].style.opacity = '0';
                    setTimeout(function() {
                        if (alerts[i] && alerts[i].parentNode) {
                            alerts[i].parentNode.removeChild(alerts[i]);
                        }
                    }, 500);
                }
            }
        }, 5000);

        // Dynamic greeting
        function updateGreeting() {
            const hour = new Date().getHours();
            const greetingElement = document.querySelector('.welcome-text h2');
            let greeting = '';
            
            if (hour < 12) {
                greeting = 'Hyvää huomenta';
            } else if (hour < 18) {
                greeting = 'Hyvää päivää';
            } else {
                greeting = 'Hyvää iltaa';
            }
            
            if (greetingElement) {
                greetingElement.innerHTML = `${greeting}, <?php echo htmlspecialchars($user['etunimi']); ?>! 👋`;
            }
        }
        
        updateGreeting();

        // Check for URL parameters to open messages
        document.addEventListener('DOMContentLoaded', function() {
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.get('open_messages') === '1') {
                openMessageModal();
            }
        });
    </script>
</body>
</html>
